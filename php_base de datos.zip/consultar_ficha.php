<?php
// Crea la conexión
$conn = mysqli_connect("localhost", "u695476605_menu_user", "@@Pedroapp2023","u695476605_menu_db");
    
// Verifica si la conexión fue exitosa
if (!$conn) {
    die("Conexión fallida: " . mysqli_connect_error());
}

// Verifica si se recibieron los parámetros ID y rol
if (isset($_POST['hora'])) {
    $roll = $_POST['hora'];
    $tipo_menu = "cenas";

    $sql = "SELECT * FROM `menu` WHERE tipo = '$tipo_menu'";
    

    // Ejecuta la consulta SQL
    $result = mysqli_query($conn, $sql);

    // Verifica si se obtuvieron resultados
    if (mysqli_num_rows($result) > 0) {
        // Obtiene los datos del primer registro
        $row = mysqli_fetch_assoc($result);

        // Construye un arreglo con los datos del usuario
        $usuario = array(
                "id" => $row["id"],
                "tipo" => $row["tipo"],
                "nombre" => $row["nombre"],
                "precio" => $row["precio"]
        );

        // Envía la respuesta como JSON
        header('Content-Type: application/json');
        echo json_encode($usuario);
    } else {
        // No se encontró ningún usuario con el ID y rol especificados
          $response = array('error' => 'No se encontraron datos de usuario');
            header("Content-type: application/json");
            echo json_encode($response);
    }
} else {
    // No se recibieron los parámetros ID y rol
      $response = array('error' => 'Faltan parametros requeridos');
      header("Content-type: application/json");
      echo json_encode($response);
}

// Cerrar la conexión
mysqli_close($conn);
?>

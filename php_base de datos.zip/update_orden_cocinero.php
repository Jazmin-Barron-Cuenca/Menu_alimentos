<?php
$conn = mysqli_connect("localhost", "u695476605_menu_user", "@@Pedroapp2023","u695476605_menu_db");
if (!$conn) {
    die("Conexión fallida: " . mysqli_connect_error());
}

$idorden = $_POST['idorden'];

$sql = "UPDATE `orden` SET `validar_coci`= 1  WHERE id = $idorden ";


if ($conn->query($sql) === TRUE) {
    echo "Orden Terminada y Notificada" ;
} else {
    echo "Error Notificada: " . $conn->error;
}

// Cierra la conexión
$conn->close();
?>

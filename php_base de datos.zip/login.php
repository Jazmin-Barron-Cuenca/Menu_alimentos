<?php

// Crea la conexión
$conn = mysqli_connect("localhost", "u695476605_menu_user", "@@Pedroapp2023","u695476605_menu_db");
    
    
// Verifica si la conexión fue exitosa
if (!$conn) {
    die("Conexión fallida: " . mysqli_connect_error());
}

// Recibir los datos por POST
$nombre = $_POST['username'];
$contrasena = $_POST['password'];

// Realiza una consulta en la tabla "arbitros"
$queryadm = "SELECT * FROM administradores WHERE nombre = '$nombre' AND clave = '$contrasena'";
$resultadm  = mysqli_query($conn, $queryadm);

// Realiza una consulta en la tabla "organizadores"
$querycocinero = "SELECT * FROM cocinero WHERE nombre = '$nombre' AND clave  = '$contrasena'";
$resultcocinero = mysqli_query($conn, $querycocinero);

// Realiza una consulta en la tabla "capitanes"
$querymesero = "SELECT * FROM mesero WHERE nombre = '$nombre' AND clave  = '$contrasena'";
$resultmesero = mysqli_query($conn, $querymesero);



if (mysqli_num_rows($resultadm) > 0) {
    // El usuario y la contraseña son válidos en la tabla "arbitros"
    $row = mysqli_fetch_assoc($resultadm);
    $response = array('id' => $row['id'], 'nombre' => $row['nombre'], 'tabla' => 'administradores');
    
} elseif (mysqli_num_rows($resultcocinero) > 0) {
    $row = mysqli_fetch_assoc($resultcocinero);
        $response = array('id' => $row['id'], 'nombre' => $row['nombre'], 'tabla' => 'cocinero');
    
} elseif (mysqli_num_rows($resultmesero) > 0) {
    $row = mysqli_fetch_assoc($resultmesero);
    $response = array('id' => $row['id'], 'nombre' => $row['nombre'], 'tabla' => 'mesero');
} else {
    // El usuario y/o la contraseña no son válidos
    $response = array('error' => 'Credenciales invalidas');
}

// Convertir el array en formato JSON
echo json_encode($response);


// Cerrar la conexión
$conn->close();
?>

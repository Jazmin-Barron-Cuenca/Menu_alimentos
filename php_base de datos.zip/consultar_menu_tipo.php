<?php
// Crea la conexión
$conn = mysqli_connect("localhost", "u695476605_menu_user", "@@Pedroapp2023","u695476605_menu_db");
    
// Verifica si la conexión fue exitosa
if (!$conn) {
    die("Conexión fallida: " . mysqli_connect_error());
}



// Definir los rangos horarios para los menús
$rango_desayunos_inicio = "08:00";
$rango_desayunos_fin = "12:00";
$rango_comidas_inicio = "12:01";
$rango_comidas_fin = "18:00";
$rango_cenas_inicio = "18:01";
$rango_cenas_fin = "23:00";

// Función para determinar el tipo de menú según la hora actual
function obtenerTipoMenu($hora) {
    global $rango_desayunos_inicio, $rango_desayunos_fin, $rango_comidas_inicio, $rango_comidas_fin, $rango_cenas_inicio, $rango_cenas_fin;
    
    if ($hora >= $rango_desayunos_inicio && $hora <= $rango_desayunos_fin) {
        return "desayunos";
    } elseif ($hora >= $rango_comidas_inicio && $hora <= $rango_comidas_fin) {
        return "comidas";
    } elseif ($hora >= $rango_cenas_inicio && $hora <= $rango_cenas_fin) {
        return "cenas";
    } else {
        return "Fuera del horario de menús";
    }
}


$hora_actual = $_POST['hora'];
//$hora_actual = "12:10";

$tipo_menu = obtenerTipoMenu($hora_actual);
$sql = "SELECT * FROM `menu` WHERE tipo = '$tipo_menu'";

    
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) >= 0) {
       $elementos_menu = array(); // Arreglo para almacenar los elementos del menú
        while ($row = mysqli_fetch_assoc($result)) {
            $elementos = array(
                "id" => $row["id"],
                "tipo" => $row["tipo"],
                "nombre" => $row["nombre"],
                "precio" => $row["precio"]
            );

            $elementos_menu[] = $elementos; // Agregar cada elemento al arreglo
        }

        // Devuelve el arreglo de elementos en formato JSON
        header('Content-Type: application/json');
        echo json_encode($elementos_menu);



} else {
        // No se encontró ningún 
          $response = array('error' => 'No se encontraron');
            header("Content-type: application/json");
            echo json_encode($response);
}


// Cerrar la conexión
mysqli_close($conn);
?>

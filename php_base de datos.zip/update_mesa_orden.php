<?php
$conn = mysqli_connect("localhost", "u695476605_menu_user", "@@Pedroapp2023","u695476605_menu_db");
if (!$conn) {
    die("Conexión fallida: " . mysqli_connect_error());
}

$numero = $_POST['numero_mesa'];

$sql = "UPDATE `mesas` SET `validar`= 1  WHERE numero = $numero";



if ($conn->query($sql) === TRUE) {
    echo "Mesa ocupada #" . $numero;
} else {
    echo "Error al ocupar mesa: " . $conn->error;
}

// Cierra la conexión
$conn->close();
?>

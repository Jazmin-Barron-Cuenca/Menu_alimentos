<?php

// Crea la conexión
$conn = mysqli_connect("localhost", "u695476605_menu_user", "@@Pedroapp2023","u695476605_menu_db");
    
// Verifica si la conexión fue exitosa
if (!$conn) {
    die("Conexión fallida: " . mysqli_connect_error());
}


// La conexión se estableció correctamente
echo "Conexión exitosa a la base de datos";

// Cerrar la conexión
$conn->close();
?>
<?php
// Crea la conexión
$conn = mysqli_connect("localhost", "u695476605_menu_user", "@@Pedroapp2023","u695476605_menu_db");
    
// Verifica si la conexión fue exitosa
if (!$conn) {
    die("Conexión fallida: " . mysqli_connect_error());
}

$sql =  "SELECT *  FROM orden WHERE validar_mese = 1 AND validar_coci = '0'";

// Crear un array para almacenar los resultados de las tres tablas
$datos = array();


$resultadoventas = mysqli_query($conn, $sql);
$datos['orden'] = array();

while ($filaventas = mysqli_fetch_assoc($resultadoventas)) {
    $datos['orden'][] = $filaventas;
}


// Cerrar la conexión a la base de datos
mysqli_close($conn);

// Devolver los datos en formato JSON
echo json_encode($datos);

?>

<?php
// Crea la conexión
$conn = mysqli_connect("localhost", "u695476605_menu_user", "@@Pedroapp2023","u695476605_menu_db");
    
// Verifica si la conexión fue exitosa
if (!$conn) {
    die("Conexión fallida: " . mysqli_connect_error());
}

// Obtiene los parámetros enviados por POST
$id = intval($_POST['id']);

$roll = $_POST['roll'];

$clave = $_POST['clave'];


// Realiza la actualización en la tabla arbitros
$sql = "UPDATE `$roll` SET`clave`='$clave' WHERE id = $id";



if ($conn->query($sql) === TRUE) {
    echo "Registro actualizado con éxito.";
} else {
    echo "Error al actualizar el registro: " . $conn->error;
}

// Cierra la conexión
$conn->close();
?>

<?php

// Crea la conexión
$conn = mysqli_connect("localhost", "u695476605_menu_user", "@@Pedroapp2023","u695476605_menu_db");
    
// Verifica si la conexión fue exitosa
if (!$conn) {
    die("Conexión fallida: " . mysqli_connect_error());
}


$sql = "SELECT * FROM mesas WHERE validar = 0";
$result = mysqli_query($conn, $sql);


if (mysqli_num_rows($result) > 0) {
    $mesas = array();
    while ($row = mysqli_fetch_assoc($result)) {
        $mesa = array(
            "id" => $row["id"],
            "numero" => $row["numero"],
            "validar" => $row["validar"]
        );
        $mesas[] = $mesa;
    }

    // Envía la respuesta como JSON
    header('Content-Type: application/json');
    echo json_encode($mesas);
} else {
    // No se encontraron usuarios en la tabla
    $mesas = array();
    $mesa = array(
            "numero" => "0",
        );
        $mesas[] = $mesa;
    header("Content-type: application/json");
    echo json_encode($mesas);
}

// Cerrar la conexión
$conn->close();

?>
<?php
// Crea la conexión
$conn = mysqli_connect("localhost", "u695476605_menu_user", "@@Pedroapp2023","u695476605_menu_db");
    
// Verifica si la conexión fue exitosa
if (!$conn) {
    die("Conexión fallida: " . mysqli_connect_error());
}

// Verifica si se recibieron los datos esperados
if ( isset($_POST['total']) && isset($_POST['numero_mesa']) && isset($_POST['id_mesero'])) {
    $total = $_POST['total'];
    $numeromesa = $_POST['numero_mesa'];
    $id_mesero = $_POST['id_mesero'];
    $idorden = $_POST['idorden'];

    $sql = "INSERT INTO `ventas`(id_mesero, numero_mesa, total) VALUES ('$id_mesero', '$numeromesa', '$total')";
    $sqlu = "UPDATE `orden` SET `validar_entrega`= 1  WHERE id = $idorden ";
    if (mysqli_query($conn, $sql)) {
        if ($conn->query($sqlu) === TRUE) {
           echo 'Envio a mesa' . $numeromesa;
        } else {
            echo "Error update: " . $conn->error;
        }
        
    } else {
        echo 'Error al insertar los datos: ' . mysqli_error($conn);
    }
    
    
} else {
    echo 'Faltan parametros';
}

// Cierra la conexión
mysqli_close($conn);
?>





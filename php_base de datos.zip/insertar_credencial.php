<?php
// Crea la conexión
$conn = mysqli_connect("localhost", "u695476605_menu_user", "@@Pedroapp2023","u695476605_menu_db");
    
// Verifica si la conexión fue exitosa
if (!$conn) {
    die("Conexión fallida: " . mysqli_connect_error());
}


// Verifica si se recibieron los datos esperados
if ( isset($_POST['roll']) && isset($_POST['nombre']) && isset($_POST['contrasena'])) {
    $roll = $_POST['roll'];
    $nombre = $_POST['nombre'];
    $contrasena = $_POST['contrasena'];
    
    

    // Realiza la consulta INSERT
    $sql = "INSERT INTO $roll (nombre, clave) VALUES ('$nombre', '$contrasena')";

    if (mysqli_query($conn, $sql)) {
        echo 'Equipo insertado correctamente';
    } else {
        echo 'Error al insertar los datos: ' . mysqli_error($conn);
    }
    
    
} else {

    echo 'Faltan parametros';
}

// Cierra la conexión
mysqli_close($conn);
?>

<?php
// Crea la conexión
$conn = mysqli_connect("localhost", "u695476605_menu_user", "@@Pedroapp2023","u695476605_menu_db");
    
// Verifica si la conexión fue exitosa
if (!$conn) {
    die("Conexión fallida: " . mysqli_connect_error());
}

// Consultas para obtener los datos de las tablas "cocinero", "administrador" y "mesero"
$sqlventas = "SELECT id_mesero, numero_mesa,Total FROM ventas";
$sqlMesero =  "SELECT id, nombre, clave  FROM mesero";

// Crear un array para almacenar los resultados de las tres tablas
$datos = array();

// Obtener los datos de la tabla "cocinero"
$resultadoventas = mysqli_query($conn, $sqlventas);
$datos['ventas'] = array();
while ($filaventas = mysqli_fetch_assoc($resultadoventas)) {
    $datos['ventas'][] = $filaventas;
}


// Obtener los datos de la tabla "mesero"
$resultadoMesero = mysqli_query($conn, $sqlMesero);
$datos['mesero'] = array();
while ($filaMesero = mysqli_fetch_assoc($resultadoMesero)) {
    $datos['mesero'][] = $filaMesero;
}

// Cerrar la conexión a la base de datos
mysqli_close($conn);

// Devolver los datos en formato JSON
echo json_encode($datos);

?>

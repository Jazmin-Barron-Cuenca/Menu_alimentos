<?php
// Crea la conexión
$conn = mysqli_connect("localhost", "u695476605_menu_user", "@@Pedroapp2023","u695476605_menu_db");
    
// Verifica si la conexión fue exitosa
if (!$conn) {
    die("Conexión fallida: " . mysqli_connect_error());
}


// Consultas para obtener los datos de las tablas "cocinero", "administrador" y "mesero"
$sqlCocinero = "SELECT id, nombre,clave FROM cocinero";
$sqlAdministrador = "SELECT id, nombre,clave  FROM administradores";
$sqlMesero =  "SELECT id, nombre,clave  FROM mesero";

// Crear un array para almacenar los resultados de las tres tablas
$datos = array();

// Obtener los datos de la tabla "cocinero"
$resultadoCocinero = mysqli_query($conn, $sqlCocinero);
$datos['cocinero'] = array();
while ($filaCocinero = mysqli_fetch_assoc($resultadoCocinero)) {
    $datos['cocinero'][] = $filaCocinero;
}

// Obtener los datos de la tabla "administrador"
$resultadoAdministrador = mysqli_query($conn, $sqlAdministrador);
$datos['administrador'] = array();
while ($filaAdministrador = mysqli_fetch_assoc($resultadoAdministrador)) {
    $datos['administrador'][] = $filaAdministrador;
}

// Obtener los datos de la tabla "mesero"
$resultadoMesero = mysqli_query($conn, $sqlMesero);
$datos['mesero'] = array();
while ($filaMesero = mysqli_fetch_assoc($resultadoMesero)) {
    $datos['mesero'][] = $filaMesero;
}

// Cerrar la conexión a la base de datos
mysqli_close($conn);

// Devolver los datos en formato JSON
echo json_encode($datos);

?>

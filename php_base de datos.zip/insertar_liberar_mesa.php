<?php
// Crea la conexión
$conn = mysqli_connect("localhost", "u695476605_menu_user", "@@Pedroapp2023","u695476605_menu_db");
    
// Verifica si la conexión fue exitosa
if (!$conn) {
    die("Conexión fallida: " . mysqli_connect_error());
}

// Verifica si se recibieron los datos esperados
if ( isset($_POST['numero_mesa'])) {
    $numeromesa = $_POST['numero_mesa'];;

    $sql = "UPDATE `mesas` SET `validar`= 0 WHERE  numero= $numeromesa ";
    $sqldelete =  "DELETE FROM `orden` WHERE `orden`.`numero_mesa` = $numeromesa";
   
    if (mysqli_query($conn, $sql)) {
        if (mysqli_query($conn, $sqldelete)) {
        
             echo 'Mesa cerrada #' . $numeromesa;
            
        } else {
            echo 'Error al insertar los datos: ' . mysqli_error($conn);
        }
        
    } else {
        echo 'Error al insertar los datos: ' . mysqli_error($conn);
    }
    
    
} else {
    echo 'Faltan parametros';
}

// Cierra la conexión
mysqli_close($conn);
?>




